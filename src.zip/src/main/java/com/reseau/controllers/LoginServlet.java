package com.reseau.controllers;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "LoginServlet", value = "/login")
public class LoginServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Affiche la page de connexion
        RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
        dispatcher.forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Récupère les données du formulaire
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        // Pour l'instant, simulation d'authentification
        if ("admin@test.com".equals(email) && "admin".equals(password)) {
            // Crée une session
            HttpSession session = request.getSession();
            session.setAttribute("userEmail", email);
            session.setAttribute("isLoggedIn", true);
            
            // Redirige vers le tableau de bord
            response.sendRedirect("dashboard.jsp");
        } else {
            // Erreur d'authentification
            request.setAttribute("errorMessage", "Email ou mot de passe incorrect");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/login.jsp");
            dispatcher.forward(request, response);
        }
    }
}