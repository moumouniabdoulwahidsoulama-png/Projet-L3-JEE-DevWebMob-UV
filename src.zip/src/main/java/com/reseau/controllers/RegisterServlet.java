package com.reseau.controllers;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "RegisterServlet", value = "/register")
public class RegisterServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/register.jsp");
        dispatcher.forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        
        // Pour l'instant, simulation d'inscription
        // Plus tard, on ajoutera à la base de données
        
        if (username != null && !username.isEmpty() && 
            email != null && !email.isEmpty() && 
            password != null && !password.isEmpty()) {
            
            // Enregistre dans la session (simulation)
            HttpSession session = request.getSession();
            session.setAttribute("userEmail", email);
            session.setAttribute("username", username);
            session.setAttribute("firstName", firstName);
            session.setAttribute("lastName", lastName);
            session.setAttribute("isLoggedIn", true);
            
            response.sendRedirect("dashboard.jsp");
        } else {
            request.setAttribute("errorMessage", "Veuillez remplir tous les champs obligatoires");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/register.jsp");
            dispatcher.forward(request, response);
        }
    }
}