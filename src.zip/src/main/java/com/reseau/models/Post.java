package com.reseau.models;

import javax.persistence.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "posts")
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
   
    @Column(nullable = false, length = 1000)
    private String content;
   
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at")
    private Date createdAt;
   
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_at")
    private Date updatedAt;
   
    // Relations
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", nullable = false)
    private User author;
   
    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Comment> comments = new ArrayList<>();
   
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "post_likes",
        joinColumns = @JoinColumn(name = "post_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private List<User> likes = new ArrayList<>();
   
    // Constructeurs
    public Post() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }
   
    public Post(String content, User author) {
        this();
        this.content = content;
        this.author = author;
    }
   
    // Getters et Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
   
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
   
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
   
    public Date getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Date updatedAt) { this.updatedAt = updatedAt; }
   
    public User getAuthor() { return author; }
    public void setAuthor(User author) { this.author = author; }
   
    public List<Comment> getComments() { return comments; }
    public void setComments(List<Comment> comments) { this.comments = comments; }
   
    public List<User> getLikes() { return likes; }
    public void setLikes(List<User> likes) { this.likes = likes; }
   
    // Méthodes utilitaires
    public void addLike(User user) {
        this.likes.add(user);
    }
   
    public void removeLike(User user) {
        this.likes.remove(user);
    }
   
    public int getLikeCount() {
        return this.likes.size();
    }
   
    public void addComment(Comment comment) {
        this.comments.add(comment);
        comment.setPost(this);
    }
   
    @PreUpdate
    public void setUpdatedAt() {
        this.updatedAt = new Date();
    }
}