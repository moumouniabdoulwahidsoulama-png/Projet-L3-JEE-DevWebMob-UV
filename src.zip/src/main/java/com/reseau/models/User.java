package com.reseau.models;

import javax.persistence.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
   
    @Column(unique = true, nullable = false, length = 50)
    private String username;
   
    @Column(unique = true, nullable = false, length = 100)
    private String email;
   
    @Column(nullable = false, length = 255)
    private String password;
   
    @Column(name = "first_name", length = 50)
    private String firstName;
   
    @Column(name = "last_name", length = 50)
    private String lastName;
   
    @Column(name = "profile_picture", length = 255)
    private String profilePicture;
   
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at")
    private Date createdAt;
   
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_at")
    private Date updatedAt;
   
    // Relations
    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Post> posts = new ArrayList<>();
   
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "user_friends",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "friend_id")
    )
    private List<User> friends = new ArrayList<>();
   
    // Constructeurs
    public User() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }
   
    public User(String username, String email, String password) {
        this();
        this.username = username;
        this.email = email;
        this.password = password;
    }
   
    // Getters et Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
   
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
   
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
   
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
   
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
   
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
   
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }
   
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
   
    public Date getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Date updatedAt) { this.updatedAt = updatedAt; }
   
    public List<Post> getPosts() { return posts; }
    public void setPosts(List<Post> posts) { this.posts = posts; }
   
    public List<User> getFriends() { return friends; }
    public void setFriends(List<User> friends) { this.friends = friends; }
   
    // Méthodes utilitaires
    public void addFriend(User friend) {
        this.friends.add(friend);
        friend.getFriends().add(this);
    }
   
    public void removeFriend(User friend) {
        this.friends.remove(friend);
        friend.getFriends().remove(this);
    }
   
    public String getFullName() {
        if (firstName != null && lastName != null) {
            return firstName + " " + lastName;
        }
        return username;
    }
   
    @PreUpdate
    public void setUpdatedAt() {
        this.updatedAt = new Date();
    }
}